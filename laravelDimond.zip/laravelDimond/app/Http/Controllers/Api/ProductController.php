<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Response;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Product::all();
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['status']        = true;
            $respond['message']       = 'Success';
            $respond['response_data'] = $obj;
        } catch (\Exception $e) {
            $respond['status']        = false;
            $respond['message']       = $e->getMessage();
            $respond['response_data'] = null;
        }
        return $respond;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list_modifed(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Product::all();
            //++++++++++++++++++++++++++++++++++++++++++++++
            return Response::apiReturnStyle(true, 'suceess', $obj, );
        } catch (\Exception $e) {
            return Response::apiReturnStyle(false, 'Error!!!', $e->getMessage(), );
        }
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list_where_clase(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Product::whereRelation("user", "status", 0)->get();
            //$obj = Product::whereRelation("user", "product_purchase_count", '>', 1)->get();
            //++++++++++++++++++++++++++++++++++++++++++++++
            return Response::apiReturnStyle(true, 'suceess', $obj, );
        } catch (\Exception $e) {
            return Response::apiReturnStyle(false, 'Error!!!', $e->getMessage(), );
        }
    }
}
