<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Foundation\Console\AboutCommand;
use Response;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Response::macro('apiReturnStyle', function ($status, $message, $value) {
            return Response::json([
                "status"  => $status,
                "message" => $message,
                "data"    => $value,
            ]);
        });
        //++++++++++++++++++++++++++++++++++++++++++++++++++++
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++
        AboutCommand::add('Webiste API Creator', [
            "type"   => "API",
            "author" => "@Code-180",
        ]);
    }
}
